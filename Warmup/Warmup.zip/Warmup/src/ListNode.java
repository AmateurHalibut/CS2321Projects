/**
 * Alex Hromada
 * Warmup Assignment
 * Node class for creating a singly linked list
 */
public class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
    }
}
